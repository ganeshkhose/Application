#include<stdio.h>
void TableRev(int iNo)
{
    
    if(iNo<0)
    {
        iNo = -iNo;
    }
    int iCnt = 0;
    printf("------------------------------------\n");
    printf("Multiplication Table of :  %d\n", iNo);
    printf("------------------------------------\n");
    for (iCnt = iNo; iCnt >= 1; iCnt--)
    {
        printf("%d\n ", iNo * iCnt);
    }
    printf("------------------------------------\n");
}

int main()
{
    int iValue = 0;
    printf("Enter Number:\n");
    scanf("%d",&iValue);
    TableRev(iValue);
    return 0;
}