// Display Multiplication Table
#include <stdio.h>
void DisplayTable(int iNo)
{
    if(iNo<0)
    {
        iNo = -iNo;
    }
    int iCnt = 0;
    printf("------------------------------------\n");
    printf("Multiplication Table of :  %d\n", iNo);
    printf("------------------------------------\n");
    for (iCnt = 1; iCnt <= 10; iCnt++)
    {
        printf("%d\n ", iNo * iCnt);
    }
    printf("------------------------------------\n");
}

int main()
{
    int iValue = 0;

    printf("Enter The Number:\n");
    scanf("%d", &iValue);

    DisplayTable(iValue);

    return 0;
}
