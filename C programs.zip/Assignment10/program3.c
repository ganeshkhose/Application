#include <stdio.h>
int KMtoMeter(int iNo)
{
    int meter = 0;
    meter = iNo * 1000;
    return meter;
}
int main()
{
    int iValue1 = 0, iRet = 0;
    printf("Enter distance :\n");
    scanf("%d", &iValue1);
    iRet = KMtoMeter(iValue1);
    printf("kilometer to meter is %d",iRet);
    return 0;
}