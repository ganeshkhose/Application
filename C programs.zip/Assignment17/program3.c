#include <stdio.h>
#include <stdlib.h>
#define TRUE 1
#define FALSE 0

typedef int BOOL;

int LargeSmallDiff(int Arr[], int iLength)
{
    int iMax = Arr[0], iCnt = 0, iMin = Arr[0];

    for (iCnt = 0; iCnt < iLength; iCnt++)
    {
        if (Arr[iCnt] > iMax)
        {
            iMax = Arr[iCnt];
        }
        else
        {
            iMin = Arr[iCnt];
        }
    }
    return iMax - iMin;
}
int main()
{
    int iSize = 0, iRet = 0, i = 0;
    int *p = NULL;

    printf("Enter The Number of elements :\n");
    scanf("%d", &iSize);

    p = (int *)malloc(iSize * sizeof(int));

    printf("enter the Elements:\n");

    for (i = 0; i < iSize; i++)
    {
        scanf("%d", &p[i]);
    }

    iRet = LargeSmallDiff(p, iSize);

    printf("Difference  is : %d\n", iRet);

    free(p);
}