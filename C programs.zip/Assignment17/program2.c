#include <stdio.h>
#include <stdlib.h>
#define TRUE 1
#define FALSE 0

typedef int BOOL;

int Minimum(int Arr[], int iLength)
{
    int iMin = Arr[0], iCnt = 0;

    for (iCnt = 0; iCnt < iLength; iCnt++) // N
    {
        if (Arr[iCnt] < iMin)
        {
            iMin = Arr[iCnt];
        }
    }
    return iMin;
}
int main()
{
    int iSize = 0, iRet = 0, i = 0;
    int *p = NULL;

    printf("Enter The Number of elements :\n");
    scanf("%d", &iSize);

    p = (int *)malloc(iSize * sizeof(int));

    printf("enter the Elements:\n");

    for (i = 0; i < iSize; i++)
    {
        scanf("%d", &p[i]);
    }

    iRet = Minimum(p, iSize);

    printf("Smallest Number is : %d\n", iRet);

    free(p);
}