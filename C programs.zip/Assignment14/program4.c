#include <stdio.h>
#include <stdlib.h>

// Step 5 : Perform the operation on array
void Display(int Arr[], int iSize)
{
    int iCnt = 0;
    printf("Elements are even and divisible by 5:\n");
    for (iCnt = 0; iCnt < iSize; iCnt++)
    {
        if ((Arr[iCnt] % 3) == 0 && (Arr[iCnt] % 5) == 0)
        {
            printf("%d\t", Arr[iCnt]);
        }
    }
}

int main()
{
    int *p = NULL;
    int iLength = 0, i = 0;

    // Step 1 : Accept size of array
    printf("Enter number of elements : \n");
    scanf("%d", &iLength);

    // Step 2 : Allocate memory for array
    p = (int *)malloc(iLength * sizeof(int));

    // Step 3 : Accept the elements of array
    printf("Enter the elements : \n");

    for (i = 0; i < iLength; i++)
    {
        scanf("%d", &p[i]);
    }

    // Step 4 : Call the function
    Display(p, iLength);

    // Step 6 : Deallocate the memory
    free(p);

    return 0;
}