#include<stdio.h>

void Display()
{
    printf("1\n");
    printf("2\n");
    printf("3\n");
    printf("4\n");
    printf("5\n");
}

int main()
{
    Display();

    return 0;
}