#include<stdio.h>
float Percentage(float iNo1,float iNo2)
{
    float iAns = 0.0;
    iAns = iNo2/iNo1*100.0;
    return iAns;
}
int main()
{
    int iValue1 = 0,iValue2 = 0;
    float fRet = 0.0;
    printf("Enter Total Marks:\n");
    scanf("%d",&iValue1);
    printf("Enter obtained Marks:\n");
    scanf("%d",&iValue2);
    fRet = Percentage(iValue1,iValue2);
    printf("%.2f",fRet);
    return 0;
}