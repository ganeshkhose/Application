#include<stdio.h>

int Product(int iNo)
{
    int iDigit = 0;
    static int iMult = 1;

    if(iNo != 0)
    {
        iDigit = iNo % 10;
        iMult = iMult * iDigit;
        iNo /= 10;
        Product(iNo);
    }
    return iMult;
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter The Number:\n");
    scanf("%d",&iValue);

    iRet = Product(iValue);
    printf("Product is :%d\n",iRet);

    return 0;
}