#include<stdio.h>

int Strlen(char *str)
{
    static int iCnt = 0;

    if(*str != '\0')
    {
       iCnt++;
       *str++;
       Strlen(str);
    }
    return iCnt;
}

int main()
{
    char arr[20];
    int iRet = 0;

    printf("Enter string:\n");
    scanf("%[^'\n']s",arr);

    iRet = Strlen(arr);

    printf("Number of Character in the String :%d\n",iRet);

    return 0;
}