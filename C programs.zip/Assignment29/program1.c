#include<stdio.h>


void Display(int iNo)
{
    int iCnt = iNo;
   
    if(iCnt >= 1)
    {
        printf("%d\t*\t",iCnt);
       
        Display(iNo-1);
    }
}

int main()
{
    int iValue = 0;

    printf("Enter Number:\n");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}