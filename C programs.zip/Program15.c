// Functional approach

// Demonstration of Sequance

// Return_Datatye Function_Name(Parameters_List)
//{
    // Function_Body        -> Sequance / Selection / Iteration / Combination of all
//}

#include<stdio.h>

void Display()
{
    printf("Jay Ganesh...\n");
    printf("Jay Ganesh...\n");
    printf("Jay Ganesh...\n");
    printf("Jay Ganesh...\n");
    printf("Jay Ganesh...\n");
}

int main()
{
    Display();

    return 0;
}