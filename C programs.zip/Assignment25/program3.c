#include <stdio.h>
int Difference(char *src)
{
    int iCnt = 0, i = 0;
    while (*src != '\0')
    {
        if ((*src >= 'a') && (*src <= 'z'))
        {
            iCnt++;
        }
        else
        {
            i++;
        }
        src++;
    }
    return iCnt - i;
}
int main()
{
    char Arr[20];
    int iRet = 0;

    printf("Enter String.\n");
    scanf("%[^'\n']s", Arr);

    iRet = Difference(Arr);
    printf("%d", iRet);

    return 0;
}