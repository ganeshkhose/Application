#include <stdio.h>
#include <stdlib.h>

int Product(int Arr[], int iSize)
{
    int iCnt = 0, iMult = 1;
    for (iCnt = 0; iCnt < iSize; iCnt++)
    {
        if (Arr[iCnt] % 2 != 0)
        {
            iMult = iMult * Arr[iCnt];
        }
    }
    return iMult;
}

int main()
{
    int *p = NULL;
    int iLength = 0, i = 0, iRet = 0;

    printf("Enter number of elements : \n");
    scanf("%d", &iLength);

    p = (int *)malloc(iLength * sizeof(int));

    printf("Enter the elements : \n");

    for (i = 0; i < iLength; i++)
    {
        scanf("%d", &p[i]);
    }

    iRet = Product(p, iLength);
    printf("product is %d", iRet);

    free(p);

    return 0;
}