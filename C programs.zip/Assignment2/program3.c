#include<stdio.h>
void Display(int iNo)
{
    if (iNo<10)
    {
        printf("Hello\n");
    }
    else
    {
        printf("Demo\n");
    }
}
int main()
{
    int iValue = 0;

    printf("Enter The Number:");
    scanf("%d",&iValue);
    Display(iValue);
    return 0;
}