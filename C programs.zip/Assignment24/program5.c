#include <stdio.h>
void Display(char ch)
{
    if ((ch >= 0) && (ch <= 127))
    {
        printf("%d\t %o\t %x\t", ch, ch, ch);
    }
}
int main()
{
    char cValue = '\0';

    printf("Enter The Character.\n");
    scanf("%c", &cValue);

    Display(cValue);
    return 0;
}