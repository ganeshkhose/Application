#include <iostream>
using namespace std;

class Numbers
{
public:
    int No;

    Numbers(int i)
    {
        No = i;
    }
    int NonFactorsSum()
    {
        int iSum = 0;
        int iCnt = 0;
        for (iCnt = 1; iCnt <= No ; iCnt++)
        {
            if ((No % iCnt) != 0)
            {
                iSum = iSum + iCnt;
            }
        }
        return iSum;
    }
};
int main()
{
    int iValue = 0,iRet = 0;

    cout << "Enter The Value :"<< "\n";

    cin >> iValue;

    Numbers obj(iValue);

    iRet = obj.NonFactorsSum();
    cout<<"NON Factors Sum are :"<<iRet<<"\n";

    return 0;
}