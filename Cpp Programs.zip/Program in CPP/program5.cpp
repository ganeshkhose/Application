#include <iostream>
using namespace std;

class Numbers
{
public:
    int No;

    Numbers(int i)
    {
        No = i;
    }
    void DisplayFactors()
    {
        int iCnt = 0;
        for (iCnt = 1; iCnt <= No; iCnt++)
        {
            if ((No % iCnt) == 0)
            {
                cout << iCnt << "\n";
            }
        }
    }
};
int main()
{
    int iValue = 0, iRet = 0;

    cout << "Enter The Value :"
         << "\n";
    cin >> iValue;

    Numbers obj(iValue);

    obj.DisplayFactors();

    return 0;
}