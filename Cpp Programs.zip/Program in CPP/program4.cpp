#include<iostream>
using namespace std;

class Numbers
{
    public:
        int No;

        Numbers(int i)
        {
            No = i;
        }
        int Factorial()
        {
            int iFact = 1;
            int iCnt = 0;
            for(iCnt = 1;iCnt <= No;iCnt++)
            {
                iFact = iFact * iCnt;
            }
            return iFact;
        }
        
};
int main()
{
    int iValue = 0,iRet = 0;

    cout<<"Enter The Value :"<<"\n";
    cin>>iValue;

    Numbers obj(iValue);

    iRet = obj.Factorial();
    cout<<"Factorial is :"<<iRet<<"\n";

    return 0;
}