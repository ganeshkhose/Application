#include<iostream>
using namespace std;
class Numbers
{
    public:
        int No;
    Numbers(int i)
    {
        No = i;
    }
    void DisplayReverse()
    {
        int iCnt = 0;
        cout<<"Reverse Number is :"<<"\n";
        for(iCnt = No;iCnt >= 1;iCnt--)
        {
            cout<<iCnt<<"\n";
        }
    }
};

int main()
{
    int iValue = 0;
    cout<<"Enter The Number:"<<"\n";
    cin>>iValue;

    Numbers obj(iValue);
    obj.DisplayReverse();

    return 0;
}