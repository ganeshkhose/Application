#include <iostream>
using namespace std;
class Numbers
{
public:
    int No;
    Numbers(int i)
    {
        No = i;
    }
    void DisplayEvenFactors()
    {
        int iCnt = 0;
        cout << "Even Factors are :"
             << "\n";
        for (iCnt = 1; iCnt <= (No / 2); iCnt++)
        {
            if ((No % iCnt == 0) && (iCnt % 2 == 0))
                cout << iCnt << "\n";
        }
    }
};

int main()
{
    int iValue = 0;
    cout << "Enter The Number:"
         << "\n";
    cin >> iValue;

    Numbers obj(iValue);
    obj.DisplayEvenFactors();

    return 0;
}