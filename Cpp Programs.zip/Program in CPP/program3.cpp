#include<iostream>
using namespace std;

class Numbers
{
    public:
        int No;

        Numbers(int i)
        {
            No = i;
        }
        int Summation()
        {
            int iSum = 0;
            int iCnt = 0;
            for(iCnt = 1;iCnt <= No;iCnt++)
            {
                iSum = iSum + iCnt;
            }
            return iSum;
        }
        
};
int main()
{
    int iValue = 0,iRet = 0;

    cout<<"Enter The Value :"<<"\n";
    cin>>iValue;

    Numbers obj(iValue);

    iRet = obj.Summation();
    cout<<"Summation is :"<<iRet<<"\n";

    return 0;
}