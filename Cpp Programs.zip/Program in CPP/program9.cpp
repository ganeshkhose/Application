#include <iostream>
using namespace std;

class Numbers
{
public:
    int No;

    Numbers(int i)
    {
        No = i;
    }
    void CheckPerfect()
    {
        int iSum = 0;
        int iCnt = 0;
        for (iCnt = 1; iCnt <= (No / 2); iCnt++)
        {
            if ((No % iCnt) == 0)
            {
                iSum = iSum + iCnt;
            }
        }
        if (iSum == No)
        {
            cout << "It is a perfect number"<< "\n";
        }
        else
        {
            cout << "It is not a perfect number"<< "\n";
        }
    }
};
int main()
{
    int iValue = 0;;

    cout << "Enter The Value :"<< "\n";

    cin >> iValue;

    Numbers obj(iValue);

    obj.CheckPerfect();

    return 0;
}