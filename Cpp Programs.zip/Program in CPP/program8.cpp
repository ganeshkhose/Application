#include <iostream>
using namespace std;

class Numbers
{
public:
    int No;

    Numbers(int i)
    {
        No = i;
    }
    int SumFactors()
    {
        int iSum = 0;
        int iCnt = 0;
        for (iCnt = 1; iCnt <= (No / 2); iCnt++)
        {
            if ((No % iCnt) == 0)
            {
                iSum = iSum + iCnt;
            }
        }
        return iSum;
    }
};
int main()
{
    int iValue = 0, iRet = 0;

    cout << "Enter The Value :"<< "\n";

    cin >> iValue;

    Numbers obj(iValue);

    iRet = obj.SumFactors();
    cout<<"Factors Sum are :"<<iRet<<"\n";
    
    return 0;
}