#include<iostream>
using namespace std;
class Numbers
{
    public:
        int No;
    Numbers(int i)
    {
        No = i;
    }
    void Multiplication()
    {
        int iCnt = 0;
        cout<<"Multiplication table is :"<<"\n";
        for(iCnt = 1;iCnt <= 10;iCnt++)
        {
            cout<<No * iCnt<<"\n";
        }
    }
};

int main()
{
    int iValue = 0;
    cout<<"Enter The Number:"<<"\n";
    cin>>iValue;

    Numbers obj(iValue);
    obj.Multiplication();

    return 0;
}