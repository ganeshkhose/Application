#include <iostream>
using namespace std;

class ArrayX
{
public:
    int *Arr;
    int iSize;

    ArrayX(int i)
    {
        cout << "Allocating the memory for resources..."
             << "\n";
        iSize = i;
        Arr = new int[iSize]; // Arr = (int *)malloc(iSize * sizeof(int));
    }

    ~ArrayX()
    {
        cout << "Deallocating the memory of resources..."
             << "\n";

        delete[] Arr; // free(Arr);
    }

    void Accept()
    {
        cout << "Enter the elements of array : "
             << "\n";

        for (int iCnt = 0; iCnt < iSize; iCnt++)
        {
            cin >> Arr[iCnt]; // scanf("%d",&Arr[iCnt]);
        }
    }

    void Display()
    {
        cout << "Elements of array are : "
             << "\n";

        for (int iCnt = 0; iCnt < iSize; iCnt++)
        {
            cout << Arr[iCnt] << "\t"; // printf("%d",Arr[iCnt]);
        }
        cout << "\n";
    }
};

class MarvellousLB : public ArrayX
{
public:
    MarvellousLB(int i) : ArrayX(i)
    {
    }

    int CheckOccurance(int A)
    {
        int iCnt = 0, iFrequency = 0;

        for (iCnt = 0; iCnt < iSize; iCnt++)
        {
            if (Arr[iCnt] == A)
            {
                iFrequency++;
            }
        }
        if (iFrequency == 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
};

int main()
{
    int iLength = 0, iNo = 0;
    bool bRet = 0;

    cout << "Enter the size of array : "
         << "\n";
    cin >> iLength;

    MarvellousLB *obj = new MarvellousLB(iLength);

    obj->Accept();
    obj->Display();

    cout << "Enter the element to findout the occurance : "
         << "\n";
    cin >> iNo;

    bRet = obj->CheckOccurance(iNo);
    if (bRet == true)
    {
        cout << iNo << " is Occured in the array"
             << "\n";
    }
    else
    {
        cout << iNo << " is not Occured in the array"
             << "\n";
    }

    delete obj;

    return 0;
}