import java.util.*;

class Pattern
{
    public void Display(int iRow,int iCol)
    {
        int i = 0,j = 0;
        
        for(i = 1;i <= iRow;i++)
        {
            for(j = 1;j <= iCol;j++)
            {
                if(j % 2 == 0)
                {
                    System.out.print("#\t");
                }
                else
                {
                    System.out.print("*\t");
                }
            }
            System.out.println();
        }
    }
}

class program5
{
    public static void main(String A[])
    {
        Scanner sobj = new Scanner (System.in);

        Pattern pobj = new Pattern();

        System.out.println("Enter The Row");
        int iNo1 = sobj.nextInt();

        System.out.println("Enter The Column");
        int iNo2 = sobj.nextInt();

        pobj.Display(iNo1,iNo2);
    }
}