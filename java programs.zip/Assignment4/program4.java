import java.util.*;

class Pattern
{
    public void Display(int iRow,int iCol)
    {
        int i = 0,j = 0;
        
        for(i = iRow;i >= 1;i--)
        {
            for(j = iCol;j >= 1;j--)
            {
                System.out.print(j+"\t");
            }
            System.out.println();
        }
    }
}

class program4
{
    public static void main(String A[])
    {
        Scanner sobj = new Scanner (System.in);

        Pattern pobj = new Pattern();

        System.out.println("Enter The Row");
        int iNo1 = sobj.nextInt();

        System.out.println("Enter The Column");
        int iNo2 = sobj.nextInt();

        pobj.Display(iNo1,iNo2);
    }
}