import java.util.*;

class Program267
{
    public static void main(String Ar[])
    {
        Scanner sobj = new Scanner(System.in);

        System.out.println("Please enter your full name : ");
        String str = sobj.nextLine();

        System.out.println("Welcome "+str);
    }
}