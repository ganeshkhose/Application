import java.util.*;

class ArrayX 
{
    public int Arr[];
    public int iLength;

    public ArrayX(int iSize) 
    {
        Arr = new int[iSize];
        iLength = iSize;
    }

    public void Accept() 
    {
        int iCnt = 0;
        Scanner sobj = new Scanner(System.in);
        System.out.println("Enter Elements of Array are:");
        for (iCnt = 0; iCnt < iLength; iCnt++) 
        {
            Arr[iCnt] = sobj.nextInt();
        }
    }

    public void Display() 
    {
        System.out.println("Elements of the array are :");
        for (int iCnt = 0; iCnt < iLength; iCnt++)
        {
            System.out.println(Arr[iCnt]);
        }
    }

    public int Difference() 
    {
        int iEvenSum = 0, iOddSum = 0;

        for (int iCnt = 0; iCnt < iLength; iCnt++)
        {
            if (Arr[iCnt] % 2 == 0) {
                iEvenSum = iEvenSum + Arr[iCnt];
            } else {
                iOddSum = iOddSum + Arr[iCnt];
            }
        }
        return iEvenSum - iOddSum;
    }
}

class program1 
{
    public static void main(String A[]) 
    {
        Scanner sobj = new Scanner(System.in);

        int iSize = 0;
        System.out.println("Enter The Size of Array:");
        iSize = sobj.nextInt();

        ArrayX obj = new ArrayX(iSize);
        obj.Accept();
        obj.Display();
        int iRet = obj.Difference();
        System.out.println("Differnce is :"+iRet);
    }
}