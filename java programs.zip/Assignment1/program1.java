import java.util.*;

class StringDemo
{
    public int CountCapitalLetter(String s)
    {
        int iCnt = 0;
        for(int i = 0;i < s.length();i++)
        {
            if((s.charAt(i)>='A') &&(s.charAt(i)<='Z'))
            {
                iCnt++;
            }
        }
        return iCnt;
    }
}
public class program1 
{
    public static void main (String A[])
    {
        Scanner sobj = new Scanner(System.in);
        System.out.println("Enter The String:");
        String str = sobj.nextLine();

        StringDemo obj = new StringDemo();
        int iRet = obj.CountCapitalLetter(str);
        System.out.println("Number of capital case  Letter:"+iRet);
    }
}
