import java.util.*;

class StringDemo
{
    public int CountDiff(String s)
    {
        int iCnt = 0;
        int j = 0;
        for(int i = 0;i < s.length();i++)
        {
            if((s.charAt(i)>='a') &&(s.charAt(i)<='z'))
            {
                iCnt++;
            }
            else
            {
                j++;
            }
        }
        return iCnt - j;
    }
}
public class program3
{
    public static void main (String A[])
    {
        Scanner sobj = new Scanner(System.in);
        System.out.println("Enter The String:");
        String str = sobj.nextLine();

        StringDemo obj = new StringDemo();
        int iRet = obj.CountDiff(str);
        System.out.println("Diifference between Small and capital character is :"+iRet);
    }
}
