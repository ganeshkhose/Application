import java.util.*;

class StringDemo
{
    public int CountSmallLetter(String s)
    {
        int iCnt = 0;
        for(int i = 0;i < s.length();i++)
        {
            if((s.charAt(i)>='a') &&(s.charAt(i)<='z'))
            {
                iCnt++;
            }
        }
        return iCnt;
    }
}
public class program2
{
    public static void main (String A[])
    {
        Scanner sobj = new Scanner(System.in);
        System.out.println("Enter The String:");
        String str = sobj.nextLine();

        StringDemo obj = new StringDemo();
        int iRet = obj.CountSmallLetter(str);
        System.out.println("Number of Small case  Letter:"+iRet);
    }
}
