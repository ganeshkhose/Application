import java.util.*;

class Numbers
{
    public int Factorial(int iValue)
    {
        int iFact = 1;
        int iCnt = 0;
        for(iCnt = 1 ;iCnt<= iValue;iCnt++)
        {
            iFact = iFact * iCnt;
        }
        return iFact;
    }
}
class program2 
{
    public static void main (String A[])
    {
        Scanner sobj = new Scanner(System.in);

        System.out.println("Enter The Value");
        int iNo = sobj.nextInt();

        Numbers obj = new Numbers();

        int iRet = obj.Factorial(iNo);
        System.out.println("Factorial of "+iNo +" is:"+iRet);
    }    
}

