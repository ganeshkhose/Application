import java.util.*;

class Numbers 
{
    public int Summation(int iValue)
    {
        int iSum = 0;
        int iCnt  = 0;
        for(iCnt = 1;iCnt <=iValue;iCnt++)
        {
            iSum = iSum + iCnt;
        }
        return iSum;
    }
}

class program1 
{
    public static void main(String arg[]) 
    {
        Scanner sobj = new Scanner(System.in);
        System.out.println("Enter The Numbers");
        int iNo =sobj. nextInt();

        Numbers nobj = new Numbers();
        int iRet = nobj.Summation(iNo);
        System.out.println("The Summation is :"+iRet);

    }

}