import java.util.*;

class DigitX
{
    public int iValue;
    public DigitX(int iNo)
    {
        iValue = iNo;
    }
    public int CountOddDigit()
    {
        int iDigit = 0;
        int iCnt = 0;
        while(iValue != 0)
        {
            iDigit = iValue % 10;
            if(iDigit % 2 != 0)
            {
                iCnt++;
            }
            iValue = iValue/10;
        }
        return iCnt;
    }
}

class program2
{
    public static void main(String A[])
    {
        Scanner sobj = new Scanner(System.in);

        int iNo = 0;

        System.out.println("Enter The Number:");
        iNo = sobj.nextInt();

        DigitX dobj = new DigitX(iNo);
        int iRet = dobj.CountOddDigit();
        System.out.println("Odd Digit Count are:"+iRet);
    }
}