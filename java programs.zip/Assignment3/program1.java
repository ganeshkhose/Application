import java.util.*;

class DigitX
{
    public int iValue;
    public DigitX(int iNo)
    {
        iValue = iNo;
    }
    public int CountDigitEven()
    {
        int iDigit = 0;
        int iCnt = 0;
        while(iValue != 0)
        {
            iDigit = iValue % 10;
            if(iDigit % 2 == 0)
            {
                iCnt++;
            }
            iValue = iValue/10;
        }
        return iCnt;
    }
        

}

class program1
{
    public static void main(String A[])
    {
        Scanner sobj = new Scanner(System.in);

        int iNo = 0;

        System.out.println("Enter The Number:");
        iNo = sobj.nextInt();

        DigitX dobj = new DigitX(iNo);
        int iRet = dobj.CountDigitEven();
        System.out.println("Even Digit Count are:"+iRet);
    }
}