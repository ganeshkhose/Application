import java.util.*;

class DigitX
{
    public int iValue;
    public DigitX(int iNo)
    {
        iValue = iNo;
    }
    public int Multiplication()
    {
        int iDigit = 0,iFact = 1;
        while(iValue != 0)
        {
            iDigit = iValue % 10;
            iFact = iFact * iDigit;
            iValue = iValue/10;
        }
        return iFact;
    }
}

class program3
{
    public static void main(String A[])
    {
        Scanner sobj = new Scanner(System.in);

        int iNo = 0;

        System.out.println("Enter The Number:");
        iNo = sobj.nextInt();

        DigitX dobj = new DigitX(iNo);
        int iRet = dobj.Multiplication();
        System.out.println("Multiplication is:"+iRet);
    }
}